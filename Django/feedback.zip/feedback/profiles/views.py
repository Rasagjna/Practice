from django.http import HttpResponseRedirect
from django.shortcuts import render
from django.views import View
from django.views.generic import ListView
from django.views.generic.edit import CreateView, FormView

from .forms import ProfileForm
from .models import UserProfile

# Create your views here.
# def store_file(file):
#     with open("temp/html.txt","wb+") as dest:
#         for chunk in file.chunks():
#             dest.write(chunk)

class CreateProfileView(CreateView):
    model=UserProfile
    fields = "__all__"
    template_name = "profiles/create_profile.html"
    success_url = "/profiles"
# class CreateProfileView(View):
#     def get(self, request):
#         form=ProfileForm()
#         return render(request, "profiles/create_profile.html",{
#             "form":form
#         })

#     def post(self, request):
#         # print(request.FILES["image"])
#         submited_form = ProfileForm(request.POST,request.FILES)
#         if submited_form.is_valid():

#             # store_file(request.FILES["image"])
#             profile= UserProfile(image=request.FILES["user_image"])
#             profile.save()
#             return HttpResponseRedirect("/profiles")
#         return render(request,"profiles/create_profile.html",{
#             "form":submited_form
#         })
        
class ProfilesView(ListView):
    model=UserProfile
    template_name = "profiles/user_profiles.html"
    context_object_name = "profiles"